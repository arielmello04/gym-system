// src/main/java/com/gymsystem/checkin/CheckinProvider.java
package com.gymsystem.checkin;

/** External providers supported by the app. */
public enum CheckinProvider {
    GYMPASS, TOTALPASS, DIRECT
}
