// src/main/java/com/gymsystem/payments/PaymentStatus.java
package com.gymsystem.payments;

public enum PaymentStatus {
    PENDING,
    PAID,
    FAILED
}
