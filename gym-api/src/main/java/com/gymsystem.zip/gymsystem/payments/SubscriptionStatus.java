// src/main/java/com/gymsystem/payments/SubscriptionStatus.java
package com.gymsystem.payments;

public enum SubscriptionStatus {
    ACTIVE,
    PAST_DUE,
    CANCELED
}
