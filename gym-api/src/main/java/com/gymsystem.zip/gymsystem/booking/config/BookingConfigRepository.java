    // src/main/java/com/gymsystem/booking/config/BookingConfigRepository.java
    package com.gymsystem.booking.config;

    import org.springframework.data.jpa.repository.JpaRepository;

    public interface BookingConfigRepository extends JpaRepository<BookingConfig, Boolean> { }
